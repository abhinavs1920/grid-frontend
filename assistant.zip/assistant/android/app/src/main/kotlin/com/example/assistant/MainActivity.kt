package com.example.assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
