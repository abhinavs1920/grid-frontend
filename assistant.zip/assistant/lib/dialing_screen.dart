import 'package:flutter/material.dart';
import 'ongoing_call_screen.dart'; // Import the ongoing call screen
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_spinkit/flutter_spinkit.dart'; // Import the flutter_spinkit package
import 'package:shared_preferences/shared_preferences.dart';

class DialingScreen extends StatefulWidget {
  final Map<String, String> seller;

  DialingScreen({required this.seller});

  @override
  _DialingScreenState createState() => _DialingScreenState();
}

class _DialingScreenState extends State<DialingScreen> {
  @override
  void initState() {
    super.initState();
    _makeCallRequest();
  }

  Future<void> _makeCallRequest() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String userName = prefs.getString('name') ?? 'Unknown User';
    String userDetails =
        'Name: ${prefs.getString('name')}, Email: ${prefs.getString('email')}, Phone: ${prefs.getString('phone')}, Age: ${prefs.getString('age')}, Gender: ${prefs.getString('gender')}, Interests: ${prefs.getStringList('interests')?.join(', ')}';

    final response = await http.post(
      Uri.parse('http://192.168.137.1:3000/process'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'seller': 'ElectroFix',
        'user': userName,
      }),
    );

    print(response.body);

    final responseData = jsonDecode(response.body);
    if (responseData['threadId'] != null &&
        responseData['threadId'].isNotEmpty) {
      // Save threadId to local storage
      await prefs.setString('threadId', responseData['threadId']);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => OngoingCallScreen(seller: widget.seller),
        ),
      );
    } else {
      // Handle other statuses if needed
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dialing ${widget.seller['name']}'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(Icons.phone, size: 100, color: Colors.green),
            SizedBox(height: 20),
            Text(
              'Calling ${widget.seller['name']}...',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            SpinKitFadingCircle(
              color: Colors.green,
              size: 50.0,
            ), // Show a better loading animation
          ],
        ),
      ),
    );
  }
}
