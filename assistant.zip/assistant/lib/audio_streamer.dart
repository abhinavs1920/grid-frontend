import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';

class AudioStreamer {
  final AudioPlayer _audioPlayer = AudioPlayer();
  final Completer<void> _audioCompleter = Completer<void>();

  AudioStreamer() {
    _audioPlayer.onPlayerComplete.listen((event) {
      _audioCompleter.complete();
    });
  }

  Future<void> get onAudioComplete => _audioCompleter.future;

  Future<void> streamTextToSpeech(String text) async {
    final apiUrl = 'https://api.sarvam.ai/text-to-speech';
    final apiKey =
        '40d67db8-451b-43e0-b114-0e27668c1956'; // Replace with your actual Sarvam API key

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'API-Subscription-Key': apiKey,
        },
        body: jsonEncode({
          'inputs': [text],
          'target_language_code': 'hi-IN',
          'speaker': 'maitreyi',
          'pitch': 0,
          'pace': 1,
          'loudness': 1.5,
          'speech_sample_rate': 8000,
          'enable_preprocessing': true,
          'model': 'bulbul:v1'
        }),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final base64Audio = responseData['audios'][0];
        final audioBytes = base64Decode(base64Audio);

        final tempDir = await getTemporaryDirectory();
        final tempFile = File('${tempDir.path}/temp_audio.wav');
        await tempFile.writeAsBytes(audioBytes);

        await _audioPlayer.play(DeviceFileSource(tempFile.path));
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (e) {
      print('Error streaming audio: $e');
    }
  }

  void stop() {
    _audioPlayer.stop();
  }
}
