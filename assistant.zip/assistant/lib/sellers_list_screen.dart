import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'previous_chats_screen.dart'; // Import the previous chats screen
import 'dialing_screen.dart'; // Import the dialing screen
import 'user_details_screen.dart'; // Import the user details screen

class SellersListScreen extends StatelessWidget {
  final List<Map<String, String>> sellers = [
    {
      'name': 'PenAndPine',
      'category': 'Stationary',
      'phone': '1234XXX890',
      'assistant_Id': 'asst_MHjWUjDjelpjTI0ROb1EHlWe'
    },
    {
      'name': 'ElectroFix',
      'category': 'Electronics',
      'phone': '098XXX4321',
      'assistant_Id': 'asst_tzCv4CWrKvdBSTxi4qwAekRc'
    },
    {
      'name': 'Sparta',
      'category': 'Sports',
      'phone': '112XXX4455',
      'assistant_Id': 'asst_d14BzDwutuoiZ81iRHxBco1n'
    },
    // Add more dummy sellers here
  ];

  Future<void> _logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => UserDetailsScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sellers'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () => _logout(context),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: sellers.length,
        itemBuilder: (context, index) {
          final seller = sellers[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(seller['name']!),
              subtitle: Text(seller['category']!),
              trailing: IconButton(
                icon: Icon(Icons.call),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DialingScreen(seller: seller),
                    ),
                  );
                },
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PreviousChatsScreen(seller: seller),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
