import 'package:flutter/material.dart';
import 'chat_screen.dart'; // Import the chat screen

class PreviousChatsScreen extends StatelessWidget {
  final Map<String, String> seller;

  PreviousChatsScreen({required this.seller});

  final List<Map<String, String>> previousChats = [
    {'date': '2023-10-01', 'summary': 'Discussed product details and pricing.'},
    {'date': '2023-09-25', 'summary': 'Asked about shipping options.'},
    {'date': '2023-09-20', 'summary': 'Inquired about return policy.'},
    // Add more dummy previous chats here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Previous Chats with ${seller['name']}'),
      ),
      body: ListView.builder(
        itemCount: previousChats.length,
        itemBuilder: (context, index) {
          final chat = previousChats[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(chat['date']!),
              subtitle: Text(chat['summary']!),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatScreen(seller: seller, chat: chat),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
