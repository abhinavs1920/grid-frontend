import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'audio_streamer.dart';

class OngoingCallScreen extends StatefulWidget {
  final Map<String, String> seller;

  OngoingCallScreen({required this.seller});

  @override
  _OngoingCallScreenState createState() => _OngoingCallScreenState();
}

class _OngoingCallScreenState extends State<OngoingCallScreen> {
  bool _isSpeakerEnabled = false;
  Timer? _timer;
  int _seconds = 0;
  late stt.SpeechToText _speech;
  bool _isListening = false;
  final AudioStreamer _audioStreamer = AudioStreamer();
  
  bool _isCallActive = true;
  print(_isCallActive)
  //ij
  int _answerIndex = 0;
  List<String> _answers = [];
  final Map<String, List<String>> _sellerAnswers = {
    'PenAndPine': [
      "Hi there! Let me help you find the perfect drawing book. We have a fantastic option: the  Moleskine Classic Notebook. It features a durable cover and high-quality paper, making it ideal for sketching or journaling.",
      "Sure! I'd love to help you with that. If you're interested in the  Moleskine Classic Notebook, it has a fantastic rating of   4.9. and is priced at   ₹1500 .",
      '''Let me check for you

I have one option only for now! The  Moleskine Classic Notebook  has a durable cover and high-quality paper, perfect for journaling or sketching. '''
          " If you ever have questions or need help with stationery in the future, just let me know. Have a wonderful day!"
    ],
    'Electrofix': [
      '''One fantastic option is the  SuperPhone X200 . It features a stunning 6.5-inch OLED display, 128GB of storage, and a powerful 48MP triple camera system. Plus, it has a great battery life, making it perfect for everyday use. It's priced at 699.99, down from 799.99, so you're getting a good deal!
Let me know if you want more details  or if you have a specific budget in mind!''',
      '''Bilkul! Aapko budget-friendly smartphone chahiye toh main aapko "ClassicPhone A1" recommend karungi. Ye ek feature phone hai, jo sirf ₹49.99 mein available hai. Ismein 2.4-inch display aur 1000mAh battery hai, jo kaafi accha hai basic use ke liye.

Agar aap smartphone chahte hain, toh "SuperPhone X200" bhi ek option hai, jo ₹699.99 ka hai. Ismein 6.5-inch OLED display, 128GB storage, aur 48MP triple camera system hai.

Aapko kaunsa option zyada pasand aaya''',
      '''Absolutely! I recommend the  SoundBuds Pro . They offer high-fidelity sound and come with noise cancellation for an immersive listening experience.

With a comfortable fit, they also boast a 24-hour battery life, so you can enjoy your music all day long. Plus, they're water-resistant, making them perfect for workouts or outdoor activities.

They're priced at 149.99, down from 179.99, which is a great deal! Would you like to know more about them?''',
      '''Currently, the SoundBuds Pro are priced at 149.99, down from the original 179.99. That's already a nice discount!    

How about this, I can offer you a special deal if you're interested in purchasing more than one item. For example, if you bundle them with another product, I might be able to provide an additional discount or a free accessory.

Would you like to explore that option or perhaps look at some other products that might interest you?''',
      "Koi baat nahi, Agar aapko aur madad chahiye ho ya koi sawaal ho, toh zaroor batana. Aapka din shubh ho!"
    ],
    'Sparta': [
      '''Hello! Aapke dost ke liye gift lena bahut accha idea hai. Agar unhe sports mein interest hai, toh main kuch options suggest kar sakti hoon.

1.  Asics Gel-Kayano 28 Running Shoes  - Ye shoes gel cushioning ke saath hain, jo long runs ke liye perfect hain. Unka support bhi excellent hai. Price: ₹14,000.

2.  Bowflex SelectTech 552 Dumbbells  - Ye adjustable dumbbells hain, jo versatile''',
      '''Bilkul! Aapko "Yonex Nanoray 18i Graphite Badminton Racquet" kaafi pasand aayega. Yeh racquet advanced players ke liye design kiya gaya hai, jo fast handling aur precision chahte hain.

Agar aapko aur details chahiye ya koi aur options dekhna hai, toh mujhe bataiye!''',
      "Yonex Nanoray 18i Graphite Badminton Racquet ka price hai ₹1599. Ye racquet advanced players ke liye design kiya gaya hai, jo fast handling aur precision chahte hain. Koi aur information chahiye toh pooch sakte ho!",
      "Mujhe aapki madad karke khushi hui. Agar aapko aur koi sahayata chahiye ho, toh bina kisi hichkichahat ke dobara bula lena. Take care!",
    ]
  };

  List<Map<String, String>> _conversation = [];

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _answers = _sellerAnswers[widget.seller['name']] ?? [];
    _startTimer();
    // Remove automatic start of the microphone
    // _startListening();
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _seconds++;
      });
    });
  }

  String _formatDuration(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return '$minutes:$secs';
  }

  void _startListening() async {
    bool available = await _speech.initialize();
    if (available) {
      setState(() => _isListening = true);
      _speech.listen(
        onResult: (val) async {
          setState(() {
            _conversation.add({'type': 'user', 'text': val.recognizedWords});
          });
          if (val.hasConfidenceRating && val.confidence > 0) {
            _stopListening();
            await _processUserSpeech();
          }
        },
      );
    }
  }

  void _stopListening() {
    _speech.stop();
    setState(() => _isListening = false);
  }

  Future<void> _processUserSpeech() async {
    if (_answerIndex < _answers.length) {
      String assistantResponse = _answers[_answerIndex];

      // Add random latency based on text length
      int latency = 300 + Random().nextInt(500);
      await Future.delayed(Duration(milliseconds: latency));

      // Add a random delay between 2 to 3 seconds before displaying the assistant's text
      int delay = 2000 + Random().nextInt(1000);
      await Future.delayed(Duration(milliseconds: delay));

      setState(() {
        _conversation.add({'type': 'assistant', 'text': assistantResponse});
        _answerIndex++;
      });

      await _audioStreamer.streamTextToSpeech(assistantResponse);
      // Do not automatically start listening again
      // _startListening();
    } else {
      // End the call if all answers are used
      _isCallActive = false;
      Navigator.pop(context);
    }
  }

  void _toggleMic() {
    if (_isListening) {
      _stopListening();
    } else {
      _startListening();
    }
  }

  @override
  void dispose() {
    _isCallActive = false;
    _timer?.cancel();
    _speech.stop();
    _audioStreamer.stop(); // Stop the audio player
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ongoing Call with ${widget.seller['name']}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            GestureDetector(
              onTap: _toggleMic,
              child: CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage(
                    'assets/seller_icon.png'), // Replace with actual seller icon
              ),
            ),
            SizedBox(height: 20),
            Text(
              widget.seller['name']!,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              _formatDuration(_seconds),
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _conversation.length,
                itemBuilder: (context, index) {
                  final entry = _conversation[index];
                  return ListTile(
                    title: Text(
                      entry['type'] == 'user'
                          ? 'User: ${entry['text']}'
                          : 'Assistant: ${entry['text']}',
                      style: TextStyle(fontSize: 16),
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    _isCallActive = false;
                    _audioStreamer.stop(); // Stop the audio player
                    Navigator.pop(context);
                  },
                  child: Text('End Call'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _isSpeakerEnabled = !_isSpeakerEnabled;
                    });
                  },
                  child: Text(_isSpeakerEnabled ? 'Speaker On' : 'Speaker Off'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
