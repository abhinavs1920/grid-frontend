import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'dart:typed_data';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'user_details_screen.dart'; // Import the user details screen
import 'audio_streamer.dart'; // Import the audio streamer
import 'sellers_list_screen.dart'; // Import the sellers list screen

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Voice Assistant',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FutureBuilder<bool>(
        future: _isUserDetailsSaved(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else {
            return snapshot.data == true
                ? SellersListScreen()
                : UserDetailsScreen();
          }
        },
      ),
    );
  }

  Future<bool> _isUserDetailsSaved() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('name') &&
        prefs.containsKey('email') &&
        prefs.containsKey('phone') &&
        prefs.containsKey('age') &&
        prefs.containsKey('gender') &&
        prefs.containsKey('interests');
  }
}

class VoiceAssistantPage extends StatefulWidget {
  @override
  _VoiceAssistantPageState createState() => _VoiceAssistantPageState();
}

class _VoiceAssistantPageState extends State<VoiceAssistantPage> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  late AudioPlayer _audioPlayer;
  bool _isListening = false;
  String _recognizedText = '';
  String _gptResponse = '';
  final AudioStreamer _audioStreamer = AudioStreamer();

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
    _initializeSpeechRecognition();
  }

  // Initialize speech recognition
  Future<void> _initializeSpeechRecognition() async {
    bool available = await _speech.initialize();
    if (!available) {
      // Handle the case where speech recognition is not available
      print('Speech recognition is not available on this device');
    }
  }

  // Toggle listening for voice input
  void _toggleListening() {
    if (!_isListening) {
      _startListening();
    } else {
      _stopListening();
    }
  }

  // Start listening for voice input
  void _startListening() async {
    if (await _speech.initialize()) {
      setState(() {
        _isListening = true;
        _recognizedText = '';
        _gptResponse = '';
      });
      _speech.listen(
        onResult: (result) {
          setState(() {
            _recognizedText = result.recognizedWords;
          });
        },
      );
    }
  }

  // Stop listening for voice input
  void _stopListening() {
    _speech.stop();
    setState(() {
      _isListening = false;
    });
    _processRecognizedText();
  }

  // Process the recognized text
  void _processRecognizedText() async {
    if (_recognizedText.isNotEmpty) {
      String gptResponse = await _sendToGPT(_recognizedText);
      setState(() {
        _gptResponse = gptResponse;
      });
      _speakResponse(gptResponse);
    }
  }

  // Send text to GPT-4-0-mini API
  Future<String> _sendToGPT(String text) async {
    final apiUrl = 'https://api.openai.com/v1/chat/completions';
    final apiKey =
        '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'; // Replace with your actual OpenAI API key

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization':
              'Bearer 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',
        },
        body: jsonEncode({
          'model':
              'gpt-4o-mini', // You can change this to 'gpt-4' if you have access
          'messages': [
            {'role': 'system', 'content': text},
            {'role': 'user', 'content': text},
          ],
          'max_tokens': 150,
          'temperature': 0.7,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['choices'][0]['message']['content'].trim() ??
            'No response from GPT';
      } else {
        return 'Error: ${response.statusCode} - ${response.body}';
      }
    } catch (e) {
      return 'Error: $e';
    }
  }

  // Update the _speakResponse method to use the new streaming function
  Future<void> _speakResponse(String text) async {
    await _audioStreamer.streamTextToSpeech(text);
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Voice Assistant'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Recognized Text:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(_recognizedText),
            ),
            SizedBox(height: 20),
            Text(
              'GPT Response:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(_gptResponse),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _toggleListening,
        child: Icon(_isListening ? Icons.mic : Icons.mic_none),
      ),
    );
  }
}
