import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  final Map<String, String> seller;
  final Map<String, String> chat;

  ChatScreen({required this.seller, required this.chat});

  final List<Map<String, String>> transcript = [
    {'sender': 'User', 'message': 'Hello, I am interested in your products.'},
    {'sender': 'Assistant', 'message': 'Sure, how can I help you?'},
    {'sender': 'User', 'message': 'Can you tell me more about the pricing?'},
    {'sender': 'Assistant', 'message': 'The price for this product is 100.'},
    // Add more dummy transcript messages here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat with ${seller['name']}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: transcript.length,
          itemBuilder: (context, index) {
            final message = transcript[index];
            return ListTile(
              title: Text(
                message['sender']!,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(message['message']!),
            );
          },
        ),
      ),
    );
  }
}
